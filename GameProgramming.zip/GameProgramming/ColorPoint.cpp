#include "ColorPoint.h"

int main() {
	Point p;
	ColorPoint cp;
	cp.setPoint(3, 4);
	cp.setColor("Red");
	cp.showColorPoint();
}