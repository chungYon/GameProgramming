#include<iostream>
#include "DataManager.h"


int main() {
	cout << DataMgr->getLevel();
}