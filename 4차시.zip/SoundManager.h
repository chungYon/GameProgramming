#pragma once
class SoundManager
{
};

